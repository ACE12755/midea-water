/* ==========================================================================
   美的商用净水 · 页面内直接编辑
   - 打开方式：index.html?edit=1，或连续点击左上角 Logo 5 次
   - 点文字直接改，点图片直接换
   - 修改自动保存在当前浏览器；点“完成”退出
   - “导出网页”会生成一个已带修改的 index.html，可直接替换上线
   ========================================================================== */
(function(){
  "use strict";

  var KEY = "midea_inline_edit_v1";
  var active = false;
  var pendingImage = null;
  var tapCount = 0, tapTimer = 0;
  var state = { texts:{}, images:{} };

  function load(){
    try{
      var raw = localStorage.getItem(KEY);
      if(raw){
        var o = JSON.parse(raw);
        state.texts = (o && o.texts) || {};
        state.images = (o && o.images) || {};
      }
    }catch(e){ state = {texts:{},images:{}}; }
  }
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(state)); }
    catch(e){ toast("浏览器存储空间不足，这次修改可能无法自动保存"); }
    updateBar();
  }
  function count(){
    return Object.keys(state.texts).length + Object.keys(state.images).length;
  }
  function norm(s){
    return String(s == null ? "" : s).replace(/\u00a0/g," ").replace(/\r/g,"");
  }
  function txt(el){
    return norm((el.innerText || el.textContent || "")).trim();
  }
  function esc(s){
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }

  function pathOf(el){
    if(el.id) return "#" + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id);
    var parts = [];
    while(el && el.nodeType === 1 && el !== document.body){
      var tag = el.tagName.toLowerCase();
      var idx = 1, sib = el;
      while((sib = sib.previousElementSibling)){ if(sib.tagName === el.tagName) idx++; }
      parts.unshift(tag + ":nth-of-type(" + idx + ")");
      el = el.parentElement;
    }
    return parts.length ? "body > " + parts.join(" > ") : "body";
  }

  function leafish(el){
    if(!el || !el.children) return false;
    for(var i=0;i<el.children.length;i++){ if(el.children[i].tagName !== "BR") return false; }
    return true;
  }
  function locked(el){
    return !!(el.closest && el.closest("button,a,[role=button],.tabbar,.seg,.chip,#ieBar"));
  }
  function skip(el){
    if(!el || el.nodeType !== 1) return true;
    if(/^(SCRIPT|STYLE|SVG|PATH|OPTION|SELECT|TEXTAREA|INPUT|TITLE|META|LINK|BR)$/.test(el.tagName)) return true;
    if(el.closest && el.closest("#boot,#ieBar")) return true;
    return false;
  }

  function setText(el, v){
    var hasBr = false;
    for(var i=0;i<el.children.length;i++){ if(el.children[i].tagName === "BR"){ hasBr = true; break; } }
    if(hasBr){ el.innerHTML = esc(v).replace(/\n/g,"<br>"); }
    else { el.textContent = v; }
  }

  function applyText(x){
    if(!x || !x.p) return;
    var el = null;
    try{ el = document.querySelector(x.p); }catch(e){}
    if(el && document.activeElement !== el){
      var cur = txt(el);
      if(x.f != null && cur === String(x.f).trim()){
        if(cur !== String(x.t).trim()) setText(el, x.t);
        return;
      }
      if(cur === String(x.t).trim()) return;
    }
    // 路径失效时，按原文兜底
    if(x.f == null) return;
    var all = document.querySelectorAll("body *");
    for(var i=0;i<all.length;i++){
      if(leafish(all[i]) && txt(all[i]) === String(x.f).trim()){
        if(txt(all[i]) !== String(x.t).trim()) setText(all[i], x.t);
        break;
      }
    }
  }

  function sameImg(img, f){
    var src = img.getAttribute("src") || "";
    if(src === f) return true;
    if(img.currentSrc && f && img.currentSrc.indexOf(f) >= 0) return true;
    try{
      var a = src.split("/").pop().split("?")[0];
      var b = String(f).split("/").pop().split("?")[0];
      return a && b && a === b;
    }catch(e){ return false; }
  }

  function setImage(el, data){
    el.src = data;
    el.removeAttribute("srcset");
    var pic = el.closest ? el.closest("picture") : null;
    if(pic){
      var ss = pic.querySelectorAll("source");
      for(var i=0;i<ss.length;i++){ if(ss[i].parentNode) ss[i].parentNode.removeChild(ss[i]); }
    }
  }

  function applyImage(x){
    if(!x || !x.p) return;
    var el = null;
    try{ el = document.querySelector(x.p); }catch(e){}
    if(el && el.tagName === "IMG" && sameImg(el, x.f)){ setImage(el, x.t); return; }
    if(el && el.tagName === "IMG" && el.getAttribute("src") === x.t) return;
    var imgs = document.querySelectorAll("img");
    for(var i=0;i<imgs.length;i++){
      if(sameImg(imgs[i], x.f)){ setImage(imgs[i], x.t); return; }
    }
  }

  function applyAll(){
    Object.keys(state.texts).forEach(function(k){ applyText(state.texts[k]); });
    Object.keys(state.images).forEach(function(k){ applyImage(state.images[k]); });
  }

  var scheduled = 0;
  function scheduleApply(){
    clearTimeout(scheduled);
    scheduled = setTimeout(applyAll, 320);
  }

  function updateBar(){
    var el = document.getElementById("ieCount");
    if(el) el.textContent = "已改 " + count() + " 处";
  }

  function toast(msg){
    var t = document.getElementById("ieToast");
    if(!t){
      t = document.createElement("div"); t.id = "ieToast"; document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = "on";
    clearTimeout(t.__timer);
    t.__timer = setTimeout(function(){ t.className = ""; }, 3200);
  }

  function ensureStyle(){
    if(document.getElementById("ieStyle")) return;
    var st = document.createElement("style");
    st.id = "ieStyle";
    st.textContent = [
      "#boot{display:none!important}",
      "body.boot-lock{overflow:auto!important}",
      "[data-ie]{outline:1px dashed transparent;border-radius:4px;transition:outline-color .16s,background .16s}",
      "[data-ie]:hover{outline-color:rgba(0,80,176,.28);background:rgba(0,80,176,.05)}",
      "[data-ie]:focus,[data-ie][data-ie-focus='1']{outline:2px solid #0050B0!important;background:#fff!important;box-shadow:0 0 0 4px rgba(0,80,176,.10)!important}",
      "img[data-ie-img]{cursor:pointer;transition:outline-color .16s,filter .16s}",
      "img[data-ie-img]:hover{outline:2px solid #0050B0;outline-offset:-2px;filter:brightness(.97)}",
      "#ieBar{position:fixed;left:50%;bottom:calc(env(safe-area-inset-bottom) + 84px);transform:translateX(-50%);z-index:9998;",
      "  display:flex;align-items:center;gap:6px;width:calc(100% - 24px);max-width:430px;padding:8px;",
      "  border-radius:16px;background:rgba(255,255,255,.94);backdrop-filter:saturate(1.8) blur(18px);",
      "  border:1px solid rgba(60,60,67,.16);box-shadow:0 12px 42px rgba(20,35,70,.22);font-family:inherit}",
      "#ieBar span{flex:1;min-width:0;font-size:11.5px;color:#6E6E73;padding-left:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
      "#ieBar button{flex:none;height:32px;padding:0 10px;border-radius:9px;border:1px solid rgba(60,60,67,.16);",
      "  background:#fff;color:#1D1D1F;font-size:11.5px;font-weight:700;font-family:inherit}",
      "#ieBar button[data-act=done]{background:#0050B0;border-color:#0050B0;color:#fff}",
      "#ieBar button[data-act=export]{color:#0050B0;border-color:rgba(0,80,176,.35)}",
      "#ieToast{position:fixed;left:50%;bottom:calc(env(safe-area-inset-bottom) + 140px);transform:translate(-50%,12px);",
      "  z-index:9999;max-width:88%;padding:9px 13px;border-radius:11px;background:rgba(28,28,30,.93);",
      "  color:#fff;font-size:12px;line-height:1.5;opacity:0;pointer-events:none;transition:.24s}",
      "#ieToast.on{opacity:1;transform:translate(-50%,0)}",
      "@media(max-width:380px){#ieBar button{padding:0 8px;font-size:11px}#ieBar span{font-size:10.5px}}"
    ].join("\n");
    document.head.appendChild(st);
  }

  function ensureBar(){
    if(document.getElementById("ieBar")) return;
    var bar = document.createElement("div");
    bar.id = "ieBar";
    bar.innerHTML = '<span id="ieCount">已改 0 处</span>' +
      '<button type="button" data-act="done">完成</button>' +
      '<button type="button" data-act="export">导出网站包</button>' +
      '<button type="button" data-act="reset">重置</button>';
    document.body.appendChild(bar);
    var file = document.createElement("input");
    file.type = "file"; file.accept = "image/*"; file.id = "ieFile"; file.style.display = "none";
    document.body.appendChild(file);
    updateBar();
  }

  function readFile(file){
    return new Promise(function(resolve,reject){
      var r = new FileReader();
      r.onload = function(){ resolve(String(r.result)); };
      r.onerror = reject;
      r.readAsDataURL(file);
    });
  }
  function loadImg(url){
    return new Promise(function(resolve,reject){
      var img = new Image();
      img.onload = function(){ resolve(img); };
      img.onerror = reject;
      img.src = url;
    });
  }

  async function prepare(file){
    if(!file || !/^image\//.test(file.type)) throw new Error("请选择图片");
    var raw = await readFile(file);
    if(file.size <= 180 * 1024) return { data:raw, warn:"" };
    var obj = URL.createObjectURL(file);
    var img;
    try{ img = await loadImg(obj); }
    catch(e){ URL.revokeObjectURL(obj); return { data:raw, warn:"这张图无法预览，已按原图保留" }; }
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    URL.revokeObjectURL(obj);
    if(!w || !h) return { data:raw, warn:"" };
    if(h > 7000 || w * h > 24e6){
      return { data:raw, warn:"超长图已按原图保留，导出文件会偏大" };
    }
    var max = 1600, sc = Math.min(1, max / Math.max(w, h));
    var cw = Math.max(1, Math.round(w * sc)), ch = Math.max(1, Math.round(h * sc));
    var c = document.createElement("canvas"); c.width = cw; c.height = ch;
    var ctx = c.getContext("2d");
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, 0, 0, cw, ch);
    var out = c.toDataURL("image/webp", 0.86);
    if(!out || out.indexOf("data:image/webp") !== 0) out = c.toDataURL("image/jpeg", 0.9);
    return { data:out, warn:"" };
  }

  function decorateText(el){
    if(skip(el) || el.__ie) return;
    var t = txt(el);
    if(!t || t.length > 1200) return;
    if(!leafish(el)) return;
    if(locked(el)) return;
    var path = pathOf(el);
    el.__ie = true;
    el.__ieFrom = (state.texts[path] && state.texts[path].f) || t;
    el.setAttribute("data-ie", "");
    try{ el.setAttribute("contenteditable", "plaintext-only"); }
    catch(e){ el.setAttribute("contenteditable", "true"); }
    el.addEventListener("click", function(e){ e.stopPropagation(); });
    el.addEventListener("mousedown", function(e){ e.stopPropagation(); });
    el.addEventListener("focus", function(){ el.dataset.ieFocus = "1"; });
    el.addEventListener("blur", function(){ el.dataset.ieFocus = ""; saveText(el); });
    el.addEventListener("input", function(){
      clearTimeout(el.__ieTimer);
      el.__ieTimer = setTimeout(function(){ saveText(el); }, 360);
    });
    el.addEventListener("keydown", function(e){
      if(e.key === "Enter" && !e.shiftKey){ e.preventDefault(); el.blur(); }
    });
  }

  function saveText(el){
    if(!el || !el.__ie) return;
    var path = pathOf(el);
    var from = el.__ieFrom || txt(el);
    var val = txt(el);
    if(val.trim() === String(from).trim()){
      delete state.texts[path];
    }else{
      state.texts[path] = { p:path, f:from, t:val };
    }
    save();
  }

  function decorateImage(img){
    if(!img || img.__ieImg || !img.getAttribute("src") || (img.closest && img.closest("#boot,#ieBar"))) return;
    var path = pathOf(img);
    var src = img.getAttribute("src");
    img.__ieImg = true;
    img.setAttribute("data-ie-img", "");
    img.title = "点击更换图片";
    img.addEventListener("click", function(e){
      e.preventDefault(); e.stopPropagation();
      pendingImage = { path:path, f:(state.images[path] && state.images[path].f) || src };
      var f = document.getElementById("ieFile");
      if(f){ f.value = ""; f.click(); }
    }, true);
  }

  function decorate(){
    if(!active) return;
    var all = document.querySelectorAll("body *");
    for(var i=0;i<all.length;i++){
      var el = all[i];
      if(el.tagName === "IMG") decorateImage(el);
      else decorateText(el);
    }
  }

  function enter(){
    if(active) return;
    active = true;
    document.body.classList.add("ie-on");
    ensureStyle(); ensureBar();
    applyAll();
    decorate();
    updateBar();
    toast("编辑模式：点文字改字，点图片换图");
  }

  function exit(){
    if(!active) return;
    active = false;
    document.body.classList.remove("ie-on");
    var bar = document.getElementById("ieBar"); if(bar) bar.remove();
    var file = document.getElementById("ieFile"); if(file) file.remove();
    var nodes = document.querySelectorAll("[data-ie],[data-ie-img]");
    for(var i=0;i<nodes.length;i++){
      nodes[i].removeAttribute("contenteditable");
      nodes[i].removeAttribute("data-ie");
      nodes[i].removeAttribute("data-ie-img");
      nodes[i].removeAttribute("data-ie-focus");
      nodes[i].removeAttribute("title");
      nodes[i].__ie = false; nodes[i].__ieImg = false;
    }
    toast("已保存，修改保留在当前浏览器");
    if(/[?&]edit=1/.test(location.search)){
      try{ history.replaceState({}, "", location.pathname + location.hash.replace("edit","")); }catch(e){}
    }
  }

  function reset(){
    if(!confirm("清除所有页面内修改，恢复原始内容？")) return;
    try{ localStorage.removeItem(KEY); }catch(e){}
    state = { texts:{}, images:{} };
    location.reload();
  }

  function patchCode(){
    var T = Object.keys(state.texts).map(function(k){ return state.texts[k]; });
    var I = Object.keys(state.images).map(function(k){ return state.images[k]; });
    return [
      "/* 页面内编辑 · 已写入 index.html */",
      "(function(){",
      "var T=" + JSON.stringify(T) + ";",
      "var I=" + JSON.stringify(I) + ";",
      "function txt(el){return (el.innerText||el.textContent||\"\").replace(/\\u00a0/g,\" \").replace(/\\r/g,\"\").trim();}",
      "function esc(s){return String(s).replace(/&/g,\"&amp;\").replace(/</g,\"&lt;\").replace(/>/g,\"&gt;\").replace(/\"/g,\"&quot;\");}",
      "function leafish(el){if(!el||!el.children)return false;for(var i=0;i<el.children.length;i++){if(el.children[i].tagName!==\"BR\")return false;}return true;}",
      "function setText(el,v){var br=false;for(var i=0;i<el.children.length;i++){if(el.children[i].tagName===\"BR\"){br=true;break;}}if(br){el.innerHTML=esc(v).replace(/\\n/g,\"<br>\");}else{el.textContent=v;}}",
      "function findText(x){var el=null;try{el=document.querySelector(x.p);}catch(e){}if(el&&txt(el)===String(x.f).trim())return el;var all=document.querySelectorAll(\"body *\");for(var i=0;i<all.length;i++){if(leafish(all[i])&&txt(all[i])===String(x.f).trim())return all[i];}return null;}",
      "function applyTexts(){for(var i=0;i<T.length;i++){var x=T[i],el=findText(x);if(el&&document.activeElement!==el&&txt(el)!==String(x.t).trim())setText(el,x.t);}}",
      "function sameImg(img,f){var s=img.getAttribute(\"src\")||\"\";if(s===f)return true;if(img.currentSrc&&f&&img.currentSrc.indexOf(f)>=0)return true;try{var a=s.split(\"/\").pop().split(\"?\")[0],b=String(f).split(\"/\").pop().split(\"?\")[0];return a&&b&&a===b;}catch(e){return false;}}",
      "function applyImages(){for(var i=0;i<I.length;i++){var x=I[i],el=null;try{el=document.querySelector(x.p);}catch(e){}if(!el||el.tagName!==\"IMG\"||!sameImg(el,x.f))el=null;if(!el){var imgs=document.querySelectorAll(\"img\");for(var j=0;j<imgs.length;j++){if(sameImg(imgs[j],x.f)){el=imgs[j];break;}}}if(!el)continue;el.src=x.t;el.removeAttribute(\"srcset\");var pic=el.closest?el.closest(\"picture\"):null;if(pic){var ss=pic.querySelectorAll(\"source\");for(var k=0;k<ss.length;k++){if(ss[k].parentNode)ss[k].parentNode.removeChild(ss[k]);}}}}",
      "var busy=false;function run(){if(busy)return;busy=true;try{applyTexts();applyImages();}catch(e){}busy=false;}",
      "var timer=0;function schedule(){clearTimeout(timer);timer=setTimeout(run,260);}",
      "function boot(){run();setTimeout(run,600);setTimeout(run,1600);if(window.MutationObserver){new MutationObserver(schedule).observe(document.documentElement,{childList:true,subtree:true});}setInterval(run,2500);}",
      "if(document.readyState===\"loading\"){document.addEventListener(\"DOMContentLoaded\",boot);}else{boot();}",
      "})();"
    ].join("\n");
  }

  function flush(){
    var nodes = document.querySelectorAll("[data-ie]");
    for(var i=0;i<nodes.length;i++) saveText(nodes[i]);
  }

  var crcTable = null;
  function crc32(buf){
    if(!crcTable){
      crcTable = new Uint32Array(256);
      for(var n=0;n<256;n++){
        var c=n;
        for(var k=0;k<8;k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        crcTable[n] = c >>> 0;
      }
    }
    var c = 0xFFFFFFFF;
    for(var i=0;i<buf.length;i++) c = crcTable[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function makeZip(entries){
    var now = new Date();
    var dosTime = ((now.getHours() & 31) << 11) | ((now.getMinutes() & 63) << 5) | ((now.getSeconds() >> 1) & 31);
    var dosDate = (((now.getFullYear() - 1980) & 127) << 9) | (((now.getMonth() + 1) & 15) << 5) | (now.getDate() & 31);
    var local = [], central = [], offset = 0;

    entries.forEach(function(f){
      var name = new TextEncoder().encode(f.name);
      var data = f.data || new Uint8Array(0);
      var crc = crc32(data);
      var lh = new Uint8Array(30 + name.length);
      var lv = new DataView(lh.buffer);
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(6, 0x0800, true);
      lv.setUint16(8, 0, true);
      lv.setUint16(10, dosTime, true);
      lv.setUint16(12, dosDate, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, data.length, true);
      lv.setUint32(22, data.length, true);
      lv.setUint16(26, name.length, true);
      lv.setUint16(28, 0, true);
      lh.set(name, 30);
      local.push(lh, data);

      var ch = new Uint8Array(46 + name.length);
      var cv = new DataView(ch.buffer);
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, 20, true);
      cv.setUint16(6, 20, true);
      cv.setUint16(8, 0x0800, true);
      cv.setUint16(10, 0, true);
      cv.setUint16(12, dosTime, true);
      cv.setUint16(14, dosDate, true);
      cv.setUint32(16, crc, true);
      cv.setUint32(20, data.length, true);
      cv.setUint32(24, data.length, true);
      cv.setUint16(28, name.length, true);
      cv.setUint16(30, 0, true);
      cv.setUint16(32, 0, true);
      cv.setUint16(34, 0, true);
      cv.setUint16(36, 0, true);
      cv.setUint32(38, 0, true);
      cv.setUint32(42, offset, true);
      ch.set(name, 46);
      central.push(ch);
      offset += lh.length + data.length;
    });

    var cdSize = 0; for(var i=0;i<central.length;i++) cdSize += central[i].length;
    var eocd = new Uint8Array(22);
    var ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(4, 0, true); ev.setUint16(6, 0, true);
    ev.setUint16(8, entries.length, true); ev.setUint16(10, entries.length, true);
    ev.setUint32(12, cdSize, true); ev.setUint32(16, offset, true);
    ev.setUint16(20, 0, true);

    return new Blob(local.concat(central, [eocd]), {type:"application/zip"});
  }

  function bytesOf(text){ return new TextEncoder().encode(text); }

  async function exportSite(){
    flush();
    toast("正在打包网站，请稍候…");
    try{
      var base = location.pathname;
      if(/\/$/.test(base)) base += "index.html";
      var dir = base.replace(/[^/]*$/, "");
      var html = await fetch(base + "?raw=" + Date.now(), {cache:"no-store"}).then(function(r){
        if(!r.ok) throw new Error("读取网页失败");
        return r.text();
      });
      var code = "<script>" + patchCode().replace(/<\/script/gi, "<\\/script") + "<\/script>";
      var idx = html.toLowerCase().lastIndexOf("</body>");
      html = idx >= 0 ? html.slice(0, idx) + code + html.slice(idx) : html + code;

      var manifestText = await fetch(dir + "assets-files.json?v=" + Date.now(), {cache:"no-store"}).then(function(r){
        if(!r.ok) throw new Error("读取资源清单失败");
        return r.text();
      });
      var list = JSON.parse(manifestText);
      var entries = [];
      entries.push({name:"index.html", data:bytesOf(html)});
      entries.push({name:"content-patch.js", data:bytesOf("/* 页面内编辑已写入 index.html，此文件保留为空 */\n")});
      entries.push({name:"使用说明.txt", data:bytesOf(
        "美的商用净水官网 · 页面内编辑\n\n" +
        "1. 打开 index.html?edit=1，或连续点击左上角 Logo 5 次。\n" +
        "2. 点文字直接改，点图片直接换，修改自动保存在当前浏览器。\n" +
        "3. 改完点“完成”，再点“导出网站包”，得到一个新的 assets.zip。\n" +
        "4. 用这个 assets.zip 替换仓库根目录的 assets.zip，提交后等待 1–2 分钟上线。\n"
      )});
      entries.push({name:".nojekyll", data:new Uint8Array(0)});

      var done = 0;
      for(var i=0;i<list.length;i+=6){
        var batch = list.slice(i, i+6);
        var got = await Promise.all(batch.map(async function(path){
          if(path === "assets-files.json") return null;
          if(path === "index.html" || path === "content-patch.js") return null;
          if(path === "assets/js/content-patch.js") return {name:path, data:bytesOf("/* 页面内编辑已写入 index.html，此文件保留为空 */\n")};
          try{
            var r = await fetch(dir + path + "?v=" + Date.now(), {cache:"no-store"});
            if(!r.ok) return null;
            return {name:path, data:new Uint8Array(await r.arrayBuffer())};
          }catch(e){ return null; }
        }));
        got.forEach(function(g){ if(g) entries.push(g); });
        done += batch.length;
        toast("正在打包 " + Math.min(done, list.length) + " / " + list.length);
      }
      entries.push({name:"assets-files.json", data:bytesOf(manifestText)});

      var blob = makeZip(entries);
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "assets.zip";
      document.body.appendChild(a);
      a.click();
      setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      if(blob.size > 25 * 1024 * 1024){
        toast("网站包约 " + (blob.size/1024/1024).toFixed(1) + "MB，超过 GitHub 单文件 25MB，建议少换几张长图");
      }else{
        toast("已生成 assets.zip，替换仓库根目录同名文件即可上线");
      }
    }catch(e){
      toast("打包失败：" + (e && e.message ? e.message : "请刷新后重试"));
    }
  }

  function bindBar(){
    document.addEventListener("click", function(e){
      var b = e.target && e.target.closest ? e.target.closest("#ieBar button") : null;
      if(!b) return;
      var act = b.getAttribute("data-act");
      if(act === "done") exit();
      if(act === "reset") reset();
      if(act === "export") exportSite();
    }, true);

    document.addEventListener("change", function(e){
      if(!e.target || e.target.id !== "ieFile") return;
      var file = e.target.files && e.target.files[0];
      if(!file || !pendingImage) return;
      var target = pendingImage;
      prepare(file).then(function(res){
        var img = null;
        try{ img = document.querySelector(target.path); }catch(e){}
        state.images[target.path] = { p:target.path, f:target.f, t:res.data, n:file.name || "" };
        if(img && img.tagName === "IMG") setImage(img, res.data);
        else applyImage(state.images[target.path]);
        save();
        toast(res.warn || "图片已替换");
      }).catch(function(err){ toast(err && err.message ? err.message : "图片读取失败"); });
    });
  }

  // 连点 Logo 5 次进入编辑模式
  document.addEventListener("click", function(e){
    var t = e.target;
    if(!t || !t.closest) return;
    var hit = t.closest("#navTitle, .nav__logo, header img, .brand img");
    if(!hit) return;
    tapCount++;
    clearTimeout(tapTimer);
    tapTimer = setTimeout(function(){ tapCount = 0; }, 2200);
    if(tapCount >= 5){
      tapCount = 0;
      e.preventDefault(); e.stopPropagation();
      enter();
    }
  }, true);

  load();
  bindBar();

  function boot(){
    applyAll();
    if(window.MutationObserver){
      new MutationObserver(scheduleApply).observe(document.documentElement, {childList:true, subtree:true});
    }
    setInterval(applyAll, 2600);
    if(/[?&]edit=1/.test(location.search) || location.hash === "#edit"){
      setTimeout(enter, 120);
    }
  }

  if(document.readyState === "loading"){ document.addEventListener("DOMContentLoaded", boot); }
  else { boot(); }
})();
