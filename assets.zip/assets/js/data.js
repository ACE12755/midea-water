/* ==========================================================================
   站点数据 · 2026 产品手册版
   卖点与参数来源：《美的商用净水 2026 手册》（公司简介 / 发展历程 / 荣誉资质 / 各产品页）
   
   ========================================================================== */

window.MIDEA = window.MIDEA || {};

window.MIDEA.featured = ["z60", "l1300", "r40", "r1400"];

window.MIDEA.categories = [
  { id: "all", name: "全部产品" },
  { id: "drink", name: "立式直饮" },
  { id: "pipeline", name: "壁挂管线机" },
  { id: "treatment", name: "净水设备" },
  { id: "counter", name: "台式净饮" }
];

/* ---------------- 发展历程（手册 P4） ---------------- */
window.MIDEA.timeline = [
  { year: "2001", text: "美的日电集团成立净水产品项目组，全面调研中国水环境。" },
  { year: "2006", text: "在全国多个典型区域设立水质实验室。" },
  { year: "2008", text: "成为《家用和类似用途反渗透净水机》《超滤净水机》国家标准编制组长单位。" },
  { year: "2010", text: "通过美国国家卫生基金会 NSF 认证，成功研制即滤即饮净水机。" },
  { year: "2011", text: "国家标准化管理委员会授予“采用国际标准产品标志证书”。" },
  { year: "2012", text: "与美国海苔（Hydration）签署战略合作，研制第三代 ONE-TOUCH 一体式滤芯。" },
  { year: "2015", text: "成立工程公司、重组商用净水团队，正式进入商用净水行业。" },
  { year: "2016", text: "全面启动净水器柜业务，提供创业平台。" },
  { year: "2017", text: "成为首批饮用水设备进校园推荐试点单位，参编校园饮用水装置技术要求与配置规范。" },
  { year: "2018", text: "担任《家用和类似用途冷热直饮机》团体标准组长单位，参与多项标准起草。" },
  { year: "2020", text: "成为《公共饮水设备安全设计规范》团体标准组长单位。" },
  { year: "2022", text: "完成超滤内部变革，全面开展商用净水市场开拓。" },
  { year: "2023", text: "经合规评审通过售后服务五星级认证。" },
  { year: "2024", text: "获中国轻工业联合会科学技术奖一等奖；美的第 1 亿台净水产品下线。" }
];

/* ---------------- 荣誉资质（手册 P5） ---------------- */
window.MIDEA.honors = [
  { year: "2024–2025", title: "企业非产采购优秀服务商", tag: "服务" },
  { year: "2024", title: "中国膜工业协会科学技术奖一等奖", tag: "技术" },
  { year: "2024", title: "商用净水领军品牌及影响力品牌", tag: "品牌" },
  { year: "2022–2025", title: "连续获得商用净水领军品牌", tag: "品牌" },
  { year: "2023", title: "售后服务五星级认证", tag: "服务" },
  { year: "2021", title: "净水机产品“采用国际标准产品标志证书”", tag: "标准" },
  { year: "2021", title: "中国质量检验协会 企业信用评价 AAA 级信用企业", tag: "信用" },
  { year: "2021", title: "全国饮水设备进校园推荐试点单位", tag: "校园" },
  { year: "2020", title: "《公共饮水设备安全设计规范》团体标准组长单位", tag: "标准" },
  { year: "2018", title: "国家高新技术企业", tag: "资质" },
  { year: "2018", title: "中国家用电器协会 饮水电器专业委员会主任委员单位", tag: "行业" },
  { year: "2017", title: "反渗透净水机水效限定值及水效等级强制性国家标准起草单位", tag: "标准" }
];

/* ---------------- 产品 ---------------- */
window.MIDEA.products = [
  {
    id: "z200",
    model: "Z200 Pro",
    name: "商用直饮机",
    subtitle: "双模杀菌 · 双胆步进加热 · 200G 大通量",
    category: "drink",
    image: "assets/img/products/z200/front.webp",
    brochure: "assets/img/brochures/z-series.jpg",
    tags: ["D-mod 双模杀菌", "双胆步进加热"],
    summary:
      "内置智能芯片与全新智能云系统，机器状态、换芯与故障一目了然；双胆步进加热在高峰时段火力全开。",
    highlights: [
      { title: "D-mod 双模杀菌", desc: "温水、冷水出水全路紫外杀菌，水箱 UVC-LED 持续抑菌，大肠杆菌去除率 99.9%。" },
      { title: "双引擎双胆步进加热", desc: "双胆独立加热、火力全开，高峰连续取热水不等待。" },
      { title: "200G 大通量", desc: "通量升级至 200G，制水 500 ml/min，接满一杯不必久等。" },
      { title: "SAE 智适应节能", desc: "连续 2 小时无人取水自动取消加热，支持定时开关机，省电也省心。" }
    ],
    specs: [
      ["产品型号", "Z200 Pro（ZRO1822-H2）"],
      ["额定功率", "2460 W"],
      ["标称 / 实际流量", "0.50 / 0.54 L/min"],
      ["过滤工艺", "前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "600 × 460 × 1400 mm"],
      ["联网", "IoT 远程操控、OTA 升级"]
    ],
    scenarios: ["企业办公", "学校教育", "公共机构"]
  },
  {
    id: "z80",
    model: "Z80 Pro",
    name: "商用直饮机（三温）",
    subtitle: "热水 / 常温 / 冷水，三温同机",
    category: "drink",
    image: "assets/img/products/z80/front.webp",
    brochure: "assets/img/brochures/z-series.jpg",
    tags: ["三温出水", "D-mod 杀菌"],
    summary:
      "在冷热双温之上增加冷水档，夏季高峰可分流热水取水压力；一屏看清各级滤芯与水温。",
    highlights: [
      { title: "三温同机", desc: "热水、常温水、冷水一机供应，减少多台设备占位与维护。" },
      { title: "D-mod 双模杀菌", desc: "水箱 UVC-LED 与出水紫外双重抑菌，水质更可控。" },
      { title: "步进式加热", desc: "分层进水、逐层加热，避免整箱反复沸腾。" },
      { title: "智能云系统", desc: "滤芯寿命、故障代码在屏上直读，并支持远程提醒。" }
    ],
    specs: [
      ["产品型号", "Z80 Pro（JD1851S-RO）"],
      ["额定功率", "1600 W"],
      ["标称 / 实际流量", "0.19 / 0.32 L/min"],
      ["过滤工艺", "PP + 前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "560 × 460 × 1400 mm"],
      ["出水方式", "热水 / 常温水 / 冷水"]
    ],
    scenarios: ["企业办公", "工厂园区", "公共机构"]
  },
  {
    id: "z60",
    model: "Z60 Pro",
    name: "商用直饮机（标准款）",
    subtitle: "基础双温配置，维护简单",
    category: "drink",
    image: "assets/img/products/z60/front.webp",
    brochure: "assets/img/brochures/z-series.jpg",
    tags: ["冷热双温", "紧凑机身"],
    summary:
      "与 Z80 Pro 同平台的标准配置，保留双温取水与四级过滤，适合点位分散、单点人数不多的办公场景。",
    highlights: [
      { title: "冷热双温", desc: "热水与常温水双档，覆盖冲泡与直饮。" },
      { title: "四级过滤", desc: "PP、前置炭、RO 与后置炭逐级把关，末端 UV 兜底。" },
      { title: "点按 / 按住双模式", desc: "按场景切换取水方式，人流大时按住即出、松手即停。" },
      { title: "前开门换芯", desc: "检修与换芯无需移动整机，适合租用办公场地。" }
    ],
    specs: [
      ["产品型号", "Z60 Pro（JD1750S-RO）"],
      ["额定功率", "1600 W"],
      ["标称 / 实际流量", "0.19 / 0.32 L/min"],
      ["过滤工艺", "PP + 前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "360 × 460 × 1400 mm"],
      ["取水方式", "点按 / 按住"]
    ],
    scenarios: ["企业办公", "学校教育"]
  },
  {
    id: "r30",
    model: "R30",
    name: "商用直饮机（不锈钢款）",
    subtitle: "不锈钢取水区，适合高频使用",
    category: "drink",
    image: "assets/img/products/r30/front.webp",
    brochure: "assets/img/brochures/r30.jpg",
    tags: ["不锈钢", "高频耐用"],
    summary:
      "黑色机身配不锈钢取水腔，耐磕碰、易清洁，适合车间、食堂等使用强度更高的场所。",
    highlights: [
      { title: "不锈钢取水区", desc: "取水腔与接水盘为不锈钢材质，抗腐蚀、耐刮擦。" },
      { title: "双龙头", desc: "热水与温水双龙头，分流取水人流。" },
      { title: "数字水温显示", desc: "面板显示当前水温与运行状态，便于现场巡检。" },
      { title: "高频耐用", desc: "机械按键与钢制结构，适应公共场所的高频次使用。" }
    ],
    specs: [
      ["产品型号", "R30"],
      ["产品类别", "立式商用直饮机"],
      ["取水区材质", "不锈钢"],
      ["出水方式", "热水 / 温水"],
      ["安装条件", "进水、220V 电源、地漏"]
    ],
    scenarios: ["工厂园区", "酒店商业"]
  },
  {
    id: "r40",
    model: "R40",
    name: "商用反渗透直饮机",
    subtitle: "全不锈钢机身 · 冷阴极环流杀菌",
    category: "drink",
    image: "assets/img/products/r40/front.webp",
    brochure: "assets/img/brochures/r40.jpg",
    tags: ["全不锈钢", "360° 环流杀菌"],
    summary:
      "整机不锈钢机身与取水区，反渗透净化后冷热出水；冷阴极杀菌配合 360° 环流设计，杀菌无死角。",
    highlights: [
      { title: "360° 环流杀菌", desc: "冷阴极杀菌结合环流结构，覆盖管路死角，出水无异味。" },
      { title: "双龙头双出水", desc: "热水与温水双路，加热温度可自行设定。" },
      { title: "安全出水逻辑", desc: "连续出水 100 秒自动关闭；机械非自锁按键，适配开放环境。" },
      { title: "全钢防指纹机身", desc: "表面防指纹处理，超大 LED 屏可见工作与滤芯状态。" }
    ],
    specs: [
      ["产品型号", "R40（JD1752S-RO）"],
      ["额定功率", "5100 W"],
      ["标称 / 实际流量", "1.0 / 1.18 L/min"],
      ["过滤工艺", "PP + 前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "550 × 460 × 1520 mm"],
      ["机身材质", "全不锈钢"]
    ],
    scenarios: ["工厂园区", "公共机构", "商业综合体"]
  },
  {
    id: "r1300",
    model: "R1300",
    name: "商用直饮机（大屏款）",
    subtitle: "五位立体杀菌 · 双龙头大流量",
    category: "drink",
    image: "assets/img/products/r1300/front.webp",
    brochure: "assets/img/brochures/r1300.jpg",
    tags: ["五位杀菌", "双龙头"],
    summary:
      "RO 膜除菌、无菌水箱、双 UV 与热水管路除菌构成五位立体杀菌；双龙头双开流量超过 1.5 L/min。",
    highlights: [
      { title: "五位立体杀菌", desc: "RO 膜除菌 + 无菌水箱 + 双 UV + 热水管路除菌，杯杯纯净。" },
      { title: "双龙头大流量", desc: "双开出水 > 1.5 L/min，热水与常温水可选，屏上显示水温。" },
      { title: "300GPD + 大热罐", desc: "大通量 RO 与大容量储热，满足瞬时高峰饮水。" },
      { title: "可拆接水盒", desc: "接水盒可拆卸直排污水，500 mm 接水高度容纳大容器。" }
    ],
    specs: [
      ["产品型号", "R1300（ZRO1300M-DU）"],
      ["额定功率", "2450 W"],
      ["标称 / 实际流量", "0.76 / 0.80 L/min"],
      ["过滤工艺", "PP 棉 + 活性炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "420 × 452 × 1500 mm"],
      ["特色", "极简 / 半胆节能 / 澎湃热水 / 冬模式"]
    ],
    scenarios: ["公共机构", "企业办公", "商业综合体"]
  },
  {
    id: "r1400",
    model: "R1400",
    name: "商用直饮机（旗舰）",
    subtitle: "专利全时无菌 · 双 UVC-LED",
    category: "drink",
    image: "assets/img/products/r1400/front.webp",
    brochure: "assets/img/brochures/r1400.jpg",
    tags: ["全时无菌", "双 UV"],
    summary:
      "五维立体除菌实现全时无菌；双 UVC-LED 分别守住常温水箱与末端出水，304 不锈钢管路贯穿全程。",
    highlights: [
      { title: "专利全时无菌技术", desc: "多除菌工艺组合，长时间停机后出水仍达标，无需担心菌落。" },
      { title: "双 UVC-LED", desc: "水箱端与末端出水各一组深紫外，抑菌贯穿储水与出水。" },
      { title: "304 不锈钢管路", desc: "食品级不锈钢管路与双集成水路，接头更少、漏水点更低。" },
      { title: "步进加热 + 节能", desc: "连续 2 小时不出水自动进入节能状态；三液位控制防热胆缺水。" }
    ],
    specs: [
      ["产品型号", "R1400（ZR01400M-UR）"],
      ["标称 / 实际流量", "1.01 / 1.71 L/min"],
      ["制热水流量", "35 L/h"],
      ["过滤工艺", "PP + 前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "554 × 542 × 1700 mm"],
      ["智能", "IoT 云物联、OTA 升级、双路 TDS 检测"]
    ],
    scenarios: ["企业办公", "酒店商业", "公共机构"]
  },
  {
    id: "z10",
    model: "Z10",
    name: "商用直饮机（旋钮款）",
    subtitle: "单旋钮操作，界面极简",
    category: "drink",
    image: "assets/img/products/z10/front.webp",
    brochure: "assets/img/brochures/z10.jpg",
    tags: ["旋钮取水", "三档调温"],
    summary:
      "以一枚旋钮替代按键，旋转选温、按压出水；PP + 前置炭 + RO + 后置炭 + UV 五级过滤，机身紧凑。",
    highlights: [
      { title: "单旋钮", desc: "选温与取水合并为一个动作，学习成本低。" },
      { title: "三档调温", desc: "常温水、温水、热水随心切换，覆盖日常取水。" },
      { title: "五级过滤", desc: "PP、前置炭、RO、后置炭与 UV，出水口感稳定。" },
      { title: "紧凑机身", desc: "窄体立式设计，靠墙即可安装，适合小型茶水间。" }
    ],
    specs: [
      ["产品型号", "Z10（MR0702A-D）"],
      ["标称 / 实际流量", "0.13 / 0.26 L/min"],
      ["过滤工艺", "PP + 前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "约 350 × 546 × 1060 mm"],
      ["操作方式", "旋钮 + 触控"]
    ],
    scenarios: ["企业办公", "学校教育"]
  },
  {
    id: "p20",
    model: "P20",
    name: "立式管线机",
    subtitle: "接集中净化水源的末端取水",
    category: "drink",
    image: "assets/img/products/p20/front.webp",
    brochure: "assets/img/brochures/p20.jpg",
    tags: ["立式", "集中供水"],
    summary:
      "机身内不设滤芯，水源来自集中净水主机；5L 大热罐与 1500W 功率，高峰接水不必排队。",
    highlights: [
      { title: "末端取水", desc: "接中央净水，末端只负责加热与取水，维护更集中。" },
      { title: "5L 大热罐", desc: "热罐容量 5 L，配合 1500 W 功率，连续取热水温度更稳。" },
      { title: "UVC 球形广域杀菌", desc: "水箱端紫外抑菌，从源头减少细菌滋生。" },
      { title: "窄体落地", desc: "窄体立式设计，靠墙安装，不占用茶水间通道。" }
    ],
    specs: [
      ["产品型号", "P20"],
      ["热罐容量", "5 L"],
      ["额定功率", "1500 W"],
      ["进水要求", "集中净化水"],
      ["安装方式", "落地，接净化水管路"]
    ],
    scenarios: ["企业办公", "酒店商业"]
  },
  {
    id: "l1300",
    model: "L1300",
    name: "商用直饮机（压缩机制冷）",
    subtitle: "10℃ 冰水 · 5 倍制冷速度",
    category: "drink",
    image: "assets/img/products/l1300/front.webp",
    brochure: "assets/img/brochures/l1300.jpg",
    tags: ["压缩机制冷", "双龙头"],
    summary:
      "压缩机制冷做到 10℃ 冰水、2 L/h 制冷量，是普通电子制冷的 5 倍；热 15L、温 12L、冷 2L 三舱配置。",
    highlights: [
      { title: "压缩机制冷", desc: "10℃ 冰水、2 L/h 大制冷量，连续取冷水温度不掉。" },
      { title: "三舱大容量", desc: "15L 热水 + 12L 温水 + 2L 冷罐，满足多人瞬时高峰。" },
      { title: "双龙头双出水", desc: "热水、温水、冷水多档选择，屏上可读水温。" },
      { title: "可外接分机", desc: "背面预留分机接口，可增加用水点位。" }
    ],
    specs: [
      ["产品型号", "L1300"],
      ["额定功率", "3160 W"],
      ["标称 / 实际流量", "0.76 / 0.87 L/min"],
      ["制热水流量", "50 L/h"],
      ["外形尺寸", "420 × 452 × 1500 mm"],
      ["制冷方式", "压缩机"]
    ],
    scenarios: ["工厂园区", "学校教育", "商业综合体"]
  },
  {
    id: "x1401",
    model: "X1401",
    name: "柜式直饮机",
    subtitle: "双 RO 膜 · 敞开式取水",
    category: "drink",
    image: "assets/img/products/x1401/front.webp",
    brochure: "assets/img/brochures/x1401.jpg",
    tags: ["双 RO 膜", "敞开式取水"],
    summary:
      "双 RO 膜串联净化，3100W 加热；上部敞开式取水、下部柜体可收纳耗材，适合茶水间一体化布置。",
    highlights: [
      { title: "双 RO 膜", desc: "两级 RO 串联，脱盐更彻底，适合原水硬度偏高地区。" },
      { title: "敞开式取水", desc: "无门取水、机械按键，人流大时不用等待。" },
      { title: "防溅钢网", desc: "席型密织钢网减少水花散落，台面更干爽。" },
      { title: "下置储物", desc: "柜内可收纳纸杯与耗材，减少茶水间杂物。" }
    ],
    specs: [
      ["产品型号", "X1401（XRO1401M-HR）"],
      ["额定功率", "3100 W"],
      ["标称 / 实际流量", "1.01 / 1.78 L/min"],
      ["制温开水流量", "50 L/h"],
      ["过滤工艺", "PP 棉 + 活性炭 + RO×2 + 后置炭 + UV"],
      ["外形尺寸", "970 × 410 × 1460 mm"]
    ],
    scenarios: ["企业办公", "酒店商业"]
  },

  /* ---------------- 壁挂管线机 ---------------- */
  {
    id: "cwg-da06",
    model: "CWG-DA06",
    name: "COLMO 壁挂管线机（白）",
    subtitle: "6 段控温 · 三档定量",
    category: "pipeline",
    image: "assets/img/products/cwg-da06/front.webp",
    brochure: "assets/img/brochures/cwg-da06.jpg",
    tags: ["6 段控温", "定量取水"],
    summary:
      "沸水、绿茶、泡奶、常温水、冷水与自定义六档一键选温；热水 18 L/h、冷水 0.4 L/h，接满即停。",
    highlights: [
      { title: "6 段精准控温", desc: "40–95℃ 分档，泡茶、冲奶不用兑水试温。" },
      { title: "三档定量", desc: "按杯量预设，接满自动停止，不必守着接水。" },
      { title: "专利纳米抗菌", desc: "涉水管道纳米抗菌，抗菌率 99.99%，避免水质二次污染。" },
      { title: "冷热双饮", desc: "热水 18 L/h、冷水 ≤15℃ 0.4 L/h，四季都有合适温度。" }
    ],
    specs: [
      ["产品型号", "CWG-DA06"],
      ["额定功率", "2100 W"],
      ["控温范围", "40–95℃（6 段）"],
      ["制热水流量", "18 L/h"],
      ["制冷水流量", "≤15℃，0.4 L/h"],
      ["适用水质", "RO 净水"]
    ],
    scenarios: ["企业办公", "酒店商业", "公共机构"]
  },
  {
    id: "cwg-da05",
    model: "CWG-DA05",
    name: "COLMO 壁挂管线机（深色）",
    subtitle: "与 DA06 同平台的深色版本",
    category: "pipeline",
    image: "assets/img/products/cwg-da05/front.webp",
    brochure: "assets/img/brochures/cwg-da05.jpg",
    tags: ["深色面板", "6 段控温"],
    summary:
      "同平台深色面板版本，尺寸与接口一致，便于同一项目按空间配色混搭。",
    highlights: [
      { title: "同平台混搭", desc: "与 DA06 尺寸、接口一致，可按空间配色选择。" },
      { title: "6 段控温", desc: "40–95℃ 六档，覆盖冲泡与直饮。" },
      { title: "纳米抗菌管道", desc: "食品接触用涉水管道，抗菌率 99.99%。" },
      { title: "全隐藏安装", desc: "管路隐藏于墙内，正面只留机身与取水口。" }
    ],
    specs: [
      ["产品型号", "CWG-DA05"],
      ["额定功率", "2100 W"],
      ["控温范围", "40–95℃（6 段）"],
      ["制热水流量", "18 L/h"],
      ["适用水质", "RO 净水"],
      ["安装方式", "壁挂"]
    ],
    scenarios: ["企业办公", "酒店商业"]
  },
  {
    id: "cwg-ra09",
    model: "CWG-RA09",
    name: "COLMO 壁挂管线机（黑）",
    subtitle: "6 大核心升级 · 3 档定量",
    category: "pipeline",
    image: "assets/img/products/cwg-ra09/front.webp",
    brochure: "assets/img/brochures/cwg-ra09.jpg",
    tags: ["3 档定量", "UV 抑菌"],
    summary:
      "黑色玻璃面板与定量取水，接满即停；UV 抑菌与补水状态在屏上实时显示。",
    highlights: [
      { title: "3 档定量取水", desc: "按杯量预设，接满自动停止，取水不必守着。" },
      { title: "6 段控温", desc: "泡茶、蜂蜜水、泡奶等场景一键选温。" },
      { title: "UV 抑菌", desc: "屏幕显示 UV 抑菌与补水中状态，水质可见。" },
      { title: "智感亮屏", desc: "靠近即亮，夜间取水不刺眼。" }
    ],
    specs: [
      ["产品型号", "CWG-RA09"],
      ["产品类别", "壁挂式管线机"],
      ["取水方式", "3 档定量 / 连续"],
      ["出水方式", "热水 / 冷水"],
      ["安装方式", "壁挂，接净化水源"]
    ],
    scenarios: ["企业办公", "酒店商业", "商业综合体"]
  },
  {
    id: "p908",
    model: "P908",
    name: "壁挂管线机（金属）",
    subtitle: "金属拉丝面板，公共空间友好",
    category: "pipeline",
    image: "assets/img/products/p908/front.webp",
    brochure: "assets/img/brochures/p908.jpg",
    tags: ["金属面板", "六档菜单"],
    summary:
      "金属拉丝面板耐指纹、易清洁；屏幕内置沸水、泡茶、泡枸杞、泡蜂蜜、泡奶、常温六档菜单。",
    highlights: [
      { title: "六档饮品菜单", desc: "沸水、泡茶、泡枸杞、泡蜂蜜、泡奶、常温，一键到位。" },
      { title: "定量取水", desc: "250 / 350 ml 两档预设，接满自动停。" },
      { title: "金属面板", desc: "拉丝工艺不易留指纹，日常擦拭即可。" },
      { title: "省电待机", desc: "长时间无操作自动息屏待机，降低能耗。" }
    ],
    specs: [
      ["产品型号", "P908"],
      ["产品类别", "壁挂式管线机"],
      ["预设水温", "沸水 / 泡茶 / 泡枸杞 / 泡蜂蜜 / 泡奶 / 常温"],
      ["取水量", "250 ml / 350 ml"],
      ["安装方式", "壁挂，接净化水源"]
    ],
    scenarios: ["企业办公", "公共机构"]
  },

  /* ---------------- 净水设备 ---------------- */
  {
    id: "mc830",
    model: "MC830",
    name: "厨下式商用净水器",
    subtitle: "无电无泵 · 四级过滤",
    category: "treatment",
    image: "assets/img/products/mc830/front.webp",
    brochure: "assets/img/brochures/mc830.jpg",
    tags: ["无电无泵", "耐水锤"],
    summary:
      "四支滤瓶串联的大通量净水器，无电无泵、装上即用；阶梯熔喷 PP 棉与活性炭纤维组合，兼顾流量与口感。",
    highlights: [
      { title: "无电无泵", desc: "依靠管网压力运行，安静、省电，也不受停电影响。" },
      { title: "四级过滤", desc: "PP 棉 + 炭纤维 ×2 + 后置，逐层拦截杂质与异味。" },
      { title: "耐水锤防爆", desc: "滤瓶与管路按耐压设计，适应商业管网的水锤冲击。" },
      { title: "厨下 / 壁挂两用", desc: "全场景适配，接管灵活，节省后厨空间。" }
    ],
    specs: [
      ["产品型号", "MC830"],
      ["产品类别", "厨下式商用净水器"],
      ["滤瓶配置", "PP 棉 + 炭纤维 ×2 + 后置"],
      ["运行方式", "无电无泵，管网压力驱动"],
      ["安装方式", "厨下 / 壁挂"]
    ],
    scenarios: ["酒店商业", "工厂园区", "商业综合体"]
  },
  {
    id: "n1801",
    model: "N1801",
    name: "落地净水设备（四龙头 · 不锈钢）",
    subtitle: "校园场景 · 温开水",
    category: "treatment",
    image: "assets/img/products/n1801/front.webp",
    brochure: "assets/img/brochures/n1801.jpg",
    tags: ["四龙头", "温开水"],
    summary:
      "面向校园与公共空间的落地设备，四个取水点、温开水直出；2.01 L/min 标称流量支撑课间集中取水。",
    highlights: [
      { title: "四龙头并行", desc: "四个取水点同时出水，课间高峰排队明显缓解。" },
      { title: "温开水", desc: "出水为温开水，避免儿童直接接沸水。" },
      { title: "十重安全防护", desc: "童锁、防干烧、漏水保护等多重机制，适配开放空间。" },
      { title: "全封闭除菌水箱", desc: "NF + 后置炭 + UV 组合，隔绝空气与细菌进入。" }
    ],
    specs: [
      ["产品型号", "N1801（XNF1801M-R）"],
      ["水温类型", "温开水"],
      ["额定功率", "3150 W"],
      ["标称 / 实际流量", "2.01 / 2.42 L/min"],
      ["过滤工艺", "PP 棉 + 活性炭 + NF + 后置炭 + UV"],
      ["外形尺寸", "1450 × 410 × 1460 mm"]
    ],
    scenarios: ["学校教育", "工厂园区", "公共机构"]
  },
  {
    id: "x1801",
    model: "X1801",
    name: "落地净水设备（四龙头 · 灰）",
    subtitle: "反渗透 + UV · 一级水效",
    category: "treatment",
    image: "assets/img/products/x1801/front.webp",
    brochure: "assets/img/brochures/x1801.jpg",
    tags: ["四龙头", "一级水效"],
    summary:
      "深灰柜体配不锈钢取水区，反渗透净化后四龙头取水；一级水效与降噪系统适配大堂与休息区。",
    highlights: [
      { title: "四龙头 + 2.45 L/min", desc: "四个取水点并行，高峰流量充足。" },
      { title: "反渗透 + UV", desc: "RO 膜为核心的多级过滤，末端 UV 兜底。" },
      { title: "安全童锁", desc: "取水需先解锁，防止误触烫伤。" },
      { title: "一级水效 · 降噪", desc: "环保少废水，运行噪音低，适合靠近办公区布置。" }
    ],
    specs: [
      ["产品型号", "X1801（XRO1801M-HR）"],
      ["额定功率", "3150 W"],
      ["标称 / 实际流量", "2.01 / 2.45 L/min"],
      ["过滤工艺", "PP 棉 + 活性炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "1450 × 410 × 1460 mm"],
      ["水效", "一级水效"]
    ],
    scenarios: ["商业综合体", "企业办公", "公共机构"]
  },
  {
    id: "m1800",
    model: "M1800",
    name: "商用制水主机",
    subtitle: "800G 大通量 · 20 寸集成滤芯",
    category: "treatment",
    image: "assets/img/products/m1800/front.webp",
    brochure: "assets/img/brochures/m1800.jpg",
    tags: ["800G", "UVC 末端"],
    summary:
      "轮式机柜内集成 20 寸一体式滤芯与 UVC 末端杀菌，为楼层内的饮水平台与管线机统一供水。",
    highlights: [
      { title: "800G 大通量", desc: "一台主机带动多个末端，2.38 L/min 实际出水。" },
      { title: "20 寸集成滤芯", desc: "折叠 PP 棉 + 碳棒 + UVC，渐层拦截、更换更省事。" },
      { title: "UVC-LED 末端杀菌", desc: "管路末端补一道深紫外，毫秒级启动。" },
      { title: "一级水效", desc: "净水产水率达标，长期运行更省水。" }
    ],
    specs: [
      ["产品型号", "M1800（ZRO1800M-U）"],
      ["标称 / 实际流量", "2.01 / 2.38 L/min"],
      ["过滤工艺", "PP + 前置炭 + RO + 后置炭 + UV"],
      ["外形尺寸", "554 × 577 × 1020 mm"],
      ["水效", "一级水效"]
    ],
    scenarios: ["工厂园区", "商业综合体"]
  },

  /* ---------------- 台式净饮 ---------------- */
  {
    id: "mru1088-r",
    model: "MRU1088-R",
    name: "净热一体机",
    subtitle: "UF + RO + CB 三芯 · 即热",
    category: "counter",
    image: "assets/img/products/mru1088-r/front.webp",
    brochure: "assets/img/brochures/mru1088-r.jpg",
    tags: ["三芯过滤", "即热"],
    summary:
      "台面净热一体，UF、RO、CB 三支滤芯与即热模块集成；净水 1.20 L/min，热水、温水、常温水三档。",
    highlights: [
      { title: "三芯配置", desc: "UF、RO、CB 分列，屏幕显示各芯状态。" },
      { title: "即热出水", desc: "常温水、温水、热水三档，按需加热不反复煮沸。" },
      { title: "1.20 L/min 净水", desc: "接水不必久等，适合接待台与小型茶水间。" },
      { title: "壁挂 / 台式", desc: "两种安装方式，台面放置或挂墙均可。" }
    ],
    specs: [
      ["产品型号", "MRU1088-R"],
      ["过滤工艺", "UF + RO + CB"],
      ["净水流量", "1.20 L/min"],
      ["出水方式", "热水 / 温水 / 常温水"],
      ["安装方式", "壁挂 / 台式"]
    ],
    scenarios: ["企业办公", "酒店商业"]
  },
  {
    id: "mug2501s-ur",
    model: "MUG2501S-UR",
    name: "台式净饮机（速热）",
    subtitle: "五段控温 · 2100W 速热",
    category: "counter",
    image: "assets/img/products/mug2501s-ur/front.webp",
    brochure: "assets/img/brochures/mug2501s-ur.jpg",
    tags: ["五段控温", "速热"],
    summary:
      "2100W 不锈钢厚膜加热，数秒出热水；五段控温配五档水量，机身超薄可壁挂。",
    highlights: [
      { title: "2100W 速热", desc: "厚膜加热数秒出热水，取消传热胆，减少千滚水。" },
      { title: "五段控温", desc: "常温 / 45 / 65 / 85 / 99℃，按饮品选温。" },
      { title: "五档水量", desc: "180 / 250 / 500 / 750 / 999 ml，接满即停。" },
      { title: "UV 杀菌", desc: "末端紫外抑菌，配合 RO 过滤，出水更安心。" }
    ],
    specs: [
      ["产品型号", "MUG2501S-UR"],
      ["额定功率", "2100 W"],
      ["控温", "常温 / 45 / 65 / 85 / 99℃"],
      ["水量", "180 / 250 / 500 / 750 / 999 ml"],
      ["安装方式", "台式 / 壁挂"]
    ],
    scenarios: ["企业办公"]
  },
  {
    id: "mug2501b-r",
    model: "MUG2501B-R",
    name: "台式净饮机（储热）",
    subtitle: "8 L/h 热水 · 壁挂安装",
    category: "counter",
    image: "assets/img/products/mug2501b-r/front.webp",
    brochure: "assets/img/brochures/mug2501b-r.jpg",
    tags: ["储热", "RO 净水"],
    summary:
      "壁挂式储热结构，90℃ 热水 8 L/h；RO 净水后加热，机身小巧，适合小型茶水间与走廊。",
    highlights: [
      { title: "8 L/h 热水", desc: "90℃ 热水持续供应，连续接水温度稳定。" },
      { title: "RO 净水", desc: "内置 RO 净水，接市政自来水即可使用。" },
      { title: "小巧壁挂", desc: "机身 521 × 178 × 451 mm，墙面安装不占台面。" },
      { title: "双重干烧保护", desc: "精准控温 + 过热保护，缺水自动断电。" }
    ],
    specs: [
      ["产品型号", "MUG2501B-R"],
      ["制热水流量", "8 L/h（90℃）"],
      ["适用水源", "RO 净水"],
      ["安装方式", "壁挂式"],
      ["外形尺寸", "521 × 178 × 451 mm"]
    ],
    scenarios: ["企业办公", "学校教育"]
  },
  {
    id: "znf2021-h4",
    model: "ZNF2021-H4",
    name: "儿童安全直饮机",
    subtitle: "35–48℃ 温开水 · 200 加仑",
    category: "counter",
    image: "assets/img/products/znf2021-h4/front.webp",
    brochure: "assets/img/brochures/znf2021-h4.jpg",
    tags: ["儿童友好", "200 加仑"],
    summary:
      "取水高度按儿童身高设计，出水恒温 35–48℃；200 加仑大流量与 UV 杀菌，适合幼儿园与小学。",
    highlights: [
      { title: "35–48℃ 温开水", desc: "全温出水，避免儿童接沸水烫伤。" },
      { title: "200 加仑大流量", desc: "满足幼儿园、小学课间集中取水。" },
      { title: "多重安全防护", desc: "童锁、防干烧、防漏电、防超温。" },
      { title: "水嘴 UV 杀菌", desc: "出水口紫外抑菌，守住最后一道关。" }
    ],
    specs: [
      ["产品型号", "ZNF2021-H4"],
      ["出水温度", "35–48℃（温开水）"],
      ["制水能力", "200 加仑"],
      ["杀菌", "UV-LED"],
      ["适用场景", "幼儿园 / 小学"]
    ],
    scenarios: ["学校教育", "公共机构"]
  }
  ,{
    id: "r1100",
    model: "R1100",
    name: "商用直饮机",
    subtitle: "冷热直饮 · 商用直饮机",
    category: "drink",
    image: "assets/img/products/r1100/front.webp",
    brochure: "assets/img/brochures/r1100.jpg",
    tags: ["冷热双温"],
    summary:
      "冷热双温输出的商用直饮机型，适合办公、园区与公共空间的集中取水。",
    highlights: [
      { title: "冷热双温", desc: "冷热双路输出，会议室、茶水间与休息区可按需取水。" }
    ],
    specs: [
      ["产品型号", "R1100"],
      ["类型", "商用直饮机"]
    ],
    scenarios: ["企业办公"]
  },
  {
    id: "z1100",
    model: "Z1100",
    name: "商用直饮机",
    subtitle: "冷热直饮 · 商用直饮机",
    category: "drink",
    image: "assets/img/products/z1100/front.webp",
    brochure: "assets/img/brochures/z1100.jpg",
    tags: ["冷热双温"],
    summary:
      "冷热双温输出的商用直饮机型，适合办公、园区与公共空间的集中取水。",
    highlights: [
      { title: "冷热双温", desc: "冷热双路输出，会议室、茶水间与休息区可按需取水。" }
    ],
    specs: [
      ["产品型号", "Z1100"],
      ["类型", "商用直饮机"]
    ],
    scenarios: ["企业办公"]
  },
  {
    id: "z1300",
    model: "Z1300",
    name: "商用直饮机",
    subtitle: "冷热直饮 · 商用直饮机",
    category: "drink",
    image: "assets/img/products/z1300/front.webp",
    brochure: "assets/img/brochures/z1300.jpg",
    tags: ["冷热双温"],
    summary:
      "冷热双温输出的商用直饮机型，适合办公、园区与公共空间的集中取水。",
    highlights: [
      { title: "冷热双温", desc: "冷热双路输出，会议室、茶水间与休息区可按需取水。" }
    ],
    specs: [
      ["产品型号", "Z1300"],
      ["类型", "商用直饮机"]
    ],
    scenarios: ["企业办公"]
  }
];

window.MIDEA.solutions = [
  {
    id: "office",
    name: "企业办公",
    headline: "把饮水这件事，从行政事务里拿出来。",
    lead: "多点位、多楼层，稳定与安静优先；按楼层与人数分层配置，运维集中管理。",
    needs: ["高峰时段取水排队", "点位多、维护分散", "滤芯与故障无人跟踪"],
    products: ["z60", "z80", "z200", "r1100", "r1300", "r1400", "r30", "r40"]
  },
  {
    id: "education",
    name: "学校教育",
    headline: "课间十分钟，要接得下几百人。",
    lead: "高峰承载与防烫设计优先，低龄段需单独考虑取水高度与出水温度。",
    needs: ["课间集中取水", "学生防烫与无障碍", "假期停用后的水质恢复"],
    products: ["x1401", "x1801"]
  },
  {
    id: "factory",
    name: "工厂园区",
    headline: "车间、宿舍、办公区，一套系统供水。",
    lead: "跨建筑供水优先考虑集中制水 + 末端取水，维护半径比设备数量更重要。",
    needs: ["跨区域供水", "高强度使用与耐污", "集中运维与备件"],
    products: ["r1300", "r30", "r40", "x1401", "x1801"]
  },
  {
    id: "hotel",
    name: "酒店商业",
    headline: "客人不会等水，也不会容忍异味。",
    lead: "客房、餐厅与后厨分区配置，公共区与后台设备分开管理。",
    needs: ["客房与后厨分区", "口感与异味控制", "夜间低噪运行"],
    products: ["r1300", "z60", "r1400"]
  },
  {
    id: "public",
    name: "公共机构",
    headline: "开放空间，安全优先。",
    lead: "医院、政务大厅与场馆的饮水点，需要兼顾无障碍、防烫与高频使用。",
    needs: ["无障碍取水", "防烫与童锁", "高频使用的耐久性"],
    products: ["r30", "r40", "r1300", "r1400"]
  },
  {
    id: "complex",
    name: "商业综合体",
    headline: "一栋楼的水，应该有一套账。",
    lead: "租户多样、点位分散，设备资产、能耗与报修需要被看见。",
    needs: ["多点位资产管理", "能耗与运行成本", "租户报修响应"],
    products: ["z60", "r1300", "r1400"]
  }
];

window.MIDEA.tech = [
  {
    no: "01",
    title: "深度过滤",
    desc: "从 PP 棉到 RO 膜逐级拦截；Z200 Pro 通量升级 200G，制水 500 ml/min。"
  },
  {
    no: "02",
    title: "多重杀菌",
    desc: "D-mod 双模杀菌、UVC-LED 与热水管路循环除菌，构成五位立体除菌。"
  },
  {
    no: "03",
    title: "节能与效率",
    desc: "SAE 智适应节能：2 小时无人取水自动取消加热；步进式加热避免整箱反复沸腾。"
  },
  {
    no: "04",
    title: "智慧物联",
    desc: "IoT 远程操控、OTA 在线升级、双路 TDS 与换芯提醒，多项目统一管理。"
  }
];
